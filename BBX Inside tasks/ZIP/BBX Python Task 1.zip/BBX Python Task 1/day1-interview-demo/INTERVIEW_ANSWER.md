# Interview answer

I start by creating a folder for the project and making a virtual environment with `python -m venv venv`. I activate it before installing anything, then install only the dependencies the project needs. Activation prepends the environment's `Scripts` directory on Windows (or `bin` on macOS/Linux) to `PATH`, so commands such as `python` and `pip` resolve to the project's interpreter and packages; deactivation restores the previous `PATH`.

After installing packages, I run `python -m pip freeze > requirements.txt`. The file records exact installed versions, including transitive dependencies, so another developer or CI job can recreate the same dependency set instead of silently getting newer, potentially incompatible releases. I commit that file and a `.gitignore` that excludes `venv/` and `__pycache__/`, but not the source or dependency manifest.

A virtual environment also prevents a concrete kind of conflict: one project can use a library version required by its code while another project on the same machine uses a different version, without either project overwriting the other's installation. I verify the setup by comparing `python -m pip --version` and `where python` before activation and after activation. In this demo, the activated paths point into the project's `venv`; outside it, they point to the system Python installation.
